	//update jr
	function updateStatus(){
		var bugsJira = new Array();
		var bugsNode=document.getElementsByName("jirabugs");
		if(bugsNode.length>0){
			for(var a=0;a<bugsNode.length;a++){
				var i=bugsNode[a]+"";
				bugsJira[a]=i.split("browse/")[1];
			}
				$.ajax({
				type : "POST",
				url : "updateStatus.do",
				//async:false,同步注释,因为要显示loading照片
				traditional: true,
				dataType: "json", 
				data : {"bugsJira":bugsJira},
				beforeSend : function(){ 
		            $("#loading").html("<p>please wait,loading... <img src=\"img/loading.gif\" /></p>"); 
		        }, 
				success : function(msg,status) {
					var colormap=msg.colormap;
					var keysmap=msg.keysmap;
					var num=keysmap.length;
					for(var i=0;i<keysmap.length;i++){
						var bugsNames=document.getElementsByName(keysmap[i]);
						for(var j=0;j<bugsNames.length;j++){
							//bugsNames[j].style.color = colormap[i]; //b color
							bugsNames[j].parentNode.parentNode.childNodes[1].style.color = colormap[i];
							//bugsNames[j].parentNode.parentNode.lastChild.style.color = colormap[i]; //timer color
						}
					}
					$("#loading").empty();
		            $("#loading").html("<p>loading success:  update status "+num+" !</p>"); 
				},
				error: function (data) {
			        console.info("error: " + data.responseText);
			    }
			}); 
		}else{
			$("#loading").html("<p>loading success:  update status 0 !</p>"); 
		}
 }
	$(function() {
		$("#fixed_thead").append($("#case_logB2C").clone());

		var cloneThead = $('#fixed_thead').find('table').find('thead');
		var cloneTbody = $('#fixed_thead').find('table').find('tbody');
		cloneThead.css('visibility', 'hidden');
		cloneThead.css('background', '#fff');
		cloneTbody.css('visibility', 'hidden');
		$('#fixed_thead').find('#case_logB2C').attr('id', 'case_logFake');

		var testOffset = $('#case_logB2C').offset().top;
		var B2CPTop = $("#case_logB2CP").offset().top - 180;
		var offsetRange = testOffset - $('#navbar').height();
		$(window).scroll(
				function() {
					if ($(window).scrollTop() >= offsetRange
							&& $(window).scrollTop() < B2CPTop) {
						$('#case_logFake').find('thead').css('visibility',
								'visible');
					} else {
						$('#case_logFake').find('thead').css('visibility',
								'hidden');
					}
				});
	});
	$(document).ready(function() {
		//首先将#back-to-top隐藏  
		$("#back-to-top").hide();
		//当滚动条的位置处于距顶部100像素以下时，跳转链接出现，否则消失  
		$(function() {
			$(window).scroll(function() {
				if ($(window).scrollTop() > 100) {
					$("#back-to-top").fadeIn(1500);
				} else {
					$("#back-to-top").fadeOut(1500);
				}
			});
			//当点击跳转链接后，回到页面顶部位置  
			$("#back-to-top").click(function() {
				$('body,html').animate({
					scrollTop : 0
				}, 500);
				return false;
			});
		});
	});